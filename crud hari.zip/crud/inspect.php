          <!DOCTYPE html>
          <html lang="en">
          <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>inspect</title>
          </head>
          <body>
            <?php
          echo mysqli_get_client_info();
          echo "<br>";
          printf("Client library version: %d\n", mysqli_get_client_version());
          echo "<br>";          
          $databaseHost = 'localhost';
          $databaseName = 'test';
          $databaseUsername = 'root';
          $databasePassword = '';
          
          $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
           
          
          print_r(mysqli_get_connection_stats($mysqli));
          echo "<br>"; 
          echo "<br>";   
          echo gethostname();
          echo "<br>"; 
          echo "<br>";   
          switch (connection_status())
            {
            case CONNECTION_NORMAL:
            $txt = 'Connection is in a normal state';
            break;
            case CONNECTION_ABORTED:
            $txt = 'Connection aborted';
            break;
            case CONNECTION_TIMEOUT:
            $txt = 'Connection timed out';
            break;
            case (CONNECTION_ABORTED & CONNECTION_TIMEOUT):
            $txt = 'Connection aborted and timed out';
            break;
            default:
            $txt = 'Unknown';
            break;
            }

            echo $txt;


?>
</body>
          </html>